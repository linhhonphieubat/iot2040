/*
 * UserLed.h - IOT2000 user led
 * Copyright (c) 2017 Sbl. Yolcubal
 * All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#ifndef UserButton_h
#define UserButton_h

#include "Arduino.h"

class UserButtonClass
{
public:
	bool pressed();
};

extern UserButtonClass UserButton;

#endif

