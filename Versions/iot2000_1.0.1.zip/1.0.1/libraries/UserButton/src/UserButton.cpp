/*
 * UserButton.cpp - IOT2000 user button
 * Copyright (c) 2017 Sbl. Yolcubal
 * All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#include "UserButton.h"

bool UserButtonClass::pressed() 
{
	FILE *fp = NULL;

	if (NULL == (fp = fopen("/sys/class/gpio/gpio63/value", "rb"))) {
		return false;
	}

	rewind(fp);

	char rChar;

	size_t result = fread(&rChar, sizeof(char), 1, fp);

	fclose(fp);

	if (result != sizeof(char))
		return false;

	return (rChar != '1');
}

UserButtonClass UserButton;
