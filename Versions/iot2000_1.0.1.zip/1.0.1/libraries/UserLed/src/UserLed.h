/*
 * UserLed.h - IOT2000 user led
 * Copyright (c) 2017 Sbl. Yolcubal
 * All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#ifndef UserLed_h
#define UserLed_h

#include "Arduino.h"

class UserLedClass
{
public:
	UserLedClass();
	void setOff();
	void setGreen(const bool state);
	void setRed(const bool state);
	void setOrange(const bool state);

private:
	bool _init;
};

extern UserLedClass UserLed;

#endif

