/*
TTYUART2.cpp implementation for TTY communication
Copyright (C) 2017 Sbl. Yolcubal
 */

#include "TTYUART2.h"

#include <linux/serial.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#ifndef SER_RS485_TERMINATE_BUS
#define SER_RS485_TERMINATE_BUS		(1 << 5)
#endif

// Constructors ////////////////////////////////////////////////////////////////

TTYUART2Class::TTYUART2Class(RingBuffer* pRx_buffer, uint32_t dwId, bool console)
	: TTYUARTClass(pRx_buffer, dwId, console)
{

}

// Public Methods //////////////////////////////////////////////////////////////

void TTYUART2Class::begin(const uint32_t dwBaudRate, const char *mode, bool terminate)
{
	if (mode == NULL)
		return;

	TTYUARTClass::begin(dwBaudRate);

	if (!_active)
		return;

	struct serial_rs485 rs485conf;

	rs485conf.flags = 0;

	if (strcasecmp("rs485", mode) == 0) {
		rs485conf.flags |= SER_RS485_ENABLED;
	}
	else if (strcasecmp("rs422", mode) == 0) {
		rs485conf.flags |= SER_RS485_ENABLED | SER_RS485_RX_DURING_TX;
	}
	else if (strcasecmp("rs232", mode) == 0) {
		return;
	}
	else {
		fprintf(stderr,"Invalid mode in begin(): %s\n", mode);
		return;
	}

	if (terminate)
		rs485conf.flags |= SER_RS485_TERMINATE_BUS;
	
	if (ioctl(_tty_fd, TIOCSRS485, &rs485conf) < 0) {
		fprintf(stderr, "Error on set mode in begin()");
	}
}
