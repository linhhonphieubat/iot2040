/*
 * UserLed.cpp - IOT2000 user led
 * Copyright (c) 2017 Sbl. Yolcubal
 * All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#include "Userled.h"

UserLedClass::UserLedClass()
{
	_init = false;
}

void UserLedClass::setOff()
{
	setRed(false);
	setGreen(false);
}

void UserLedClass::setRed(const bool state) 
{
	FILE *fp = NULL;

	if (NULL == (fp = fopen("/sys/class/leds/mpio_uart_led:red:user/brightness", "rb+"))) {
		return;
	}

	rewind(fp);

	fwrite(state ? "1" : "0", sizeof(char), strlen("0"), fp);

	fclose(fp);
}

void UserLedClass::setGreen(const bool state)
{
	if (!_init)
	{
		pinMode(LED_BUILTIN, OUTPUT);
		_init = true;
	}

	digitalWrite(LED_BUILTIN, state ? HIGH : LOW);
}

void UserLedClass::setOrange(const bool state)
{
	setRed(state);
	setGreen(state);
}

UserLedClass UserLed;
